package org.tnsif.stringexample;
//program to demonstrate on Object class
class Sample
{
	
}
public class ObjectClassDemoProgram {

	public static void main(String[] args) {
		Sample s=new Sample();
		System.out.println(s.getClass());
		System.out.println(s.hashCode());

	}

}
