package org.tnsif.stringexample;

//String is a final class and it is immutable
//can't inherit any final class

/*public class StringSubClass extends String{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub

	}

}
*/