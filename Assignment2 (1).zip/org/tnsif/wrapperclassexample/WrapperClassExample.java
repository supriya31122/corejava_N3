package org.tnsif.wrapperclassexample;

public class WrapperClassExample {

	public static void main(String[] args) {
		System.out.println("Welcome to TNS: ");
		
		int a=Integer.parseInt(args[0]);
		int b=Integer.parseInt(args[0]);
		
		int res=a+b;
		System.out.println(res);
	}

}
