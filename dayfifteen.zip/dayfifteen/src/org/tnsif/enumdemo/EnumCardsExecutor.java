package org.tnsif.enumdemo;


	//driver class
	public class EnumCardsExecutor {
		
		public static void main(String[] args) {
			EnumCardsDemo.DIAMOND.print();
		}

	}



