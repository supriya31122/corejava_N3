package org.tnsif.enumdemo;


	//to explain can we implement interface using enum?
	public interface InterfaceCardsDemo {
		
		//abstract method
		void print();

	}



