package daysixteen;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class junit {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
