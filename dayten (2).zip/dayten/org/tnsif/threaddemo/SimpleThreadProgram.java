package org.tnsif.threaddemo;

//program to demonstrate on Thread class
//creating a thread by extending a thread class

public class SimpleThreadProgram extends Thread {
	
	
	public void run()
	
	{
		System.out.println("Thread is in running state :");
	}

}
